						<?php 
	
	echo 'Olá mundo!';
echo 'Olá mundo!';

?>				